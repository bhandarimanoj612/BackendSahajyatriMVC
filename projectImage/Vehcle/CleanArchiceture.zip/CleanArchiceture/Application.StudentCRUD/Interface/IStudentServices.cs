﻿using Domain.StudentCRUD.Models;
using Domain.StudentCRUD.Models.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace Application.StudentCRUD.Services
{
    public  interface IStudentServices
    {
        Task<Student> AddStudent(Student student);
        Task<IEnumerable<Student>> GetAllStudent();//for getting the multiple data in list 

        Task<Student> UpdateStudent(string id, UpdateStudent updateStudent);
        Task<Student> DeleteStudent(string id);
        Task<IEnumerable<Student>> GetStudentById(string id);
    }
}
