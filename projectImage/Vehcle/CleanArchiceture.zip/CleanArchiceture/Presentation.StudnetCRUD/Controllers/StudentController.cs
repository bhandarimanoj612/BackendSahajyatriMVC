﻿using Application.StudentCRUD.Services;
using Domain.StudentCRUD.Models;
using Domain.StudentCRUD.Models.Dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.StudnetCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentServices _studentServices;

        public StudentController(IStudentServices studentServices)
        {
            _studentServices = studentServices;
        }
        [HttpPost,Route("AddStudent")]
        public async Task<IActionResult>AddStudent(Student student)
        {
            var addStudent = await  _studentServices.AddStudent(student);
            return Ok(addStudent);
        }
        [HttpGet, Route("GetAllStudent")]
        public async Task<IActionResult> GetAllStudent()
        {
            var addStudent = await _studentServices.GetAllStudent();
            return Ok(addStudent);
        }

        [HttpGet,Route("GetStudentById")]
        public async Task<IActionResult> GetStudentById(string id)
        {
            var getStudent = await _studentServices.GetStudentById(id);
            return Ok(getStudent);
        }

        [HttpPut, Route("UpdateStudetnById")]
        public async Task<IActionResult> UpdateStudentById(Guid id, [FromBody] UpdateStudent updateStudent)
        {
            var updatedStudent = await _studentServices.UpdateStudent(id.ToString(), updateStudent);
            return Ok(updatedStudent);
        }
        [HttpDelete,Route("DeleteStudentById")]
        public async Task<ActionResult>DeleteStudentById(string  id)
        {
            var deleteStudent = await _studentServices.DeleteStudent(id);
            return Ok(deleteStudent);
        }
    }
}
