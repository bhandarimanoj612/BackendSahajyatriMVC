using Application.StudentCRUD.Services;
using Domain.StudentCRUD.Models;
using Infrastructure.StudnetCRUD;
using Infrastructure.StudnetCRUD.StudentService;
using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);

// Build configuration
var configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json")
    .Build();

// Read JWT secret and email configuration from configuration source
//string jwtSecret = configuration["JWT:Secret"];
//EmailConfiguration emailConfiguration = configuration.GetSection("EmailConfiguration").Get<EmailConfiguration>();

//// Create database context with dependencies
//var dbContext = new ApplicationDbContext(jwtSecret, emailConfiguration);
// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen();


builder.Services.AddDbContext<ApplicationDbContext>();

//api key identity bitra bako kura haru yo tala ko line la kam gerxa 
builder.Services.AddIdentity<ApplicationUser,IdentityRole>().AddEntityFrameworkStores<ApplicationDbContext>()
    .AddApiEndpoints();
builder.Services.AddScoped<IStudentServices, StudentService>();
builder.Services.AddAuthentication().AddBearerToken(IdentityConstants.BearerScheme);//With this while  login we get  access token  which is called bearer token

//add Authentication 
builder.Services.AddAuthorizationBuilder();

var app = builder.Build();

// Seed roles into the database
using (var scope = app.Services.CreateScope())
{
    var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

    // Define roles
    string[] roles = { "Admin", "User" };

    // Seed roles if they don't exist
    foreach (var roleName in roles)
    {
        if (!await roleManager.RoleExistsAsync(roleName))
        {
            await roleManager.CreateAsync(new IdentityRole(roleName));
        }
    }
}

app.MapIdentityApi<ApplicationUser>();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();


app.UseAuthorization();

app.MapControllers();

app.Run();
