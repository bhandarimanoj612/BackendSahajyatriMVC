﻿using Domain.StudentCRUD.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.StudnetCRUD
{
    public  class ApplicationDbContext: IdentityDbContext<ApplicationUser>
    {
        //private readonly string _jwtSecret;
        //private readonly EmailConfiguration _emailConfiguration;

        //public ApplicationDbContext(string jwtSecret, EmailConfiguration emailConfiguration)
        public ApplicationDbContext()
        {
            //_jwtSecret = jwtSecret;
            //_emailConfiguration = emailConfiguration;
        }

        protected override void OnConfiguring (DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=MANOJ\\SQLEXPRESS;Database=CleanArchiture;TrustServerCertificate=True;Trusted_Connection=True;MultipleActiveResultSets=True");
            //// Access JWT secret and email configuration
            //var jwtSecret = _jwtSecret;
            //var emailFrom = _emailConfiguration.From;

        }
        public DbSet<Student> Students { get; set; }
    }
}
