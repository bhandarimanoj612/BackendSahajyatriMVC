﻿using Application.StudentCRUD.Services;
using Domain.StudentCRUD.Models;
using Domain.StudentCRUD.Models.Dto;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.StudnetCRUD.StudentService
{
    public class StudentService : IStudentServices
    {


        private readonly ApplicationDbContext _db;
        public StudentService(ApplicationDbContext db)
        {
            _db = db;
        }


      
        public async Task<Student> AddStudent(Student student)
        {
            var result = await _db.Students.AddAsync(student);
            await _db.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Student> DeleteStudent(string id)
        {
            var studentDelete = await _db.Students.FindAsync(Guid.Parse(id));
            if (studentDelete != null)
            {
                _db.Students.Remove(studentDelete);
                await _db.SaveChangesAsync();

            }
            return studentDelete;
        }
       

        public async Task<IEnumerable<Student>> GetAllStudent()
        {
            return await _db.Students.ToListAsync();
        }

        public async Task<IEnumerable<Student>> GetStudentById(string id)
        {
            var result = await _db.Students.Where(s => s.Id.ToString() == id).ToListAsync();
            return result;
        }

        public async Task<Student> UpdateStudent(string id, UpdateStudent updateStudent)
        {
            var studentUpdate = await _db.Students.FindAsync(Guid.Parse(id));
            if (studentUpdate != null)
            {
                studentUpdate.Name = updateStudent.Name;
                studentUpdate.Email = updateStudent.Email;
                studentUpdate.Bio = updateStudent.Bio;

                await _db.SaveChangesAsync();

                return studentUpdate; // Return the updated student
            }

            // Handle the case when the student is not found
            throw new Exception($"Student with ID {id} not found.");
        }


    }
}
